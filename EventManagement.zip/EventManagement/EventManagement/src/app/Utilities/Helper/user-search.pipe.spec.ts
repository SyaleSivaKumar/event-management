import { UserSearchPipe } from './user-search.pipe';

describe('UserSearchPipe', () => {
  it('create an instance', () => {
    const pipe = new UserSearchPipe();
    expect(pipe).toBeTruthy();
  });
});
