import { EventSearchPipe } from './event-search.pipe';

describe('EventSearchPipe', () => {
  it('create an instance', () => {
    const pipe = new EventSearchPipe();
    expect(pipe).toBeTruthy();
  });
});
