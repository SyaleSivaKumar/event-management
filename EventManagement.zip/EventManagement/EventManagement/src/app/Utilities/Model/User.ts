export class User{
    userId:any=null;
    name: string ="" ;
    email : string ="" ;
    mobile_number :number=0;
    password :string= "";
    status :number=1;
    loginAttempts :number=0;
    otp : number=0;
    role :any= "";
}