export class Booking{

    bookingId:any=null;
	status:string="pending";
	user:any=null;
	event:any =null;
}