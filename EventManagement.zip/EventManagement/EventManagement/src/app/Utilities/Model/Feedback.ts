export class Feedback{
    
    feedbackId:any=null;
	
	feedback:string=""
	
	rating:Number|any=null;
	
	userId:Number|any;

	description:string=""

}