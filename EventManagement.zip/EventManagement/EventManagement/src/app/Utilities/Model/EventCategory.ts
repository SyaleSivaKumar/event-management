export class EventCategory{

    categoryId:any=null;
	
	category:string="";

}