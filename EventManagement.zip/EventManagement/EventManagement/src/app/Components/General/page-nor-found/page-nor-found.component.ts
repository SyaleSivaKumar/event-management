import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-page-nor-found',
  templateUrl: './page-nor-found.component.html',
  styleUrls: ['./page-nor-found.component.scss']
})
export class PageNorFoundComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
