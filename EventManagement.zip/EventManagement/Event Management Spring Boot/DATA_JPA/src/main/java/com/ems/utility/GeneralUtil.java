package com.ems.utility;

public class GeneralUtil {

	public static String toJson(String text) {
		return "\""+text+"\"";
	}
}
